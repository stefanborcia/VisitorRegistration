﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VisitorBusinessLogic.Services;

namespace VisitorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        private readonly ICompanyService _companyService;

        // Constructor to inject the company service
        public CompanyController(ICompanyService companyService)
        {
            _companyService = companyService;
        }

        // API action to get all companies
        [HttpGet("companies")]
        public async Task<IActionResult> GetCompanies()
        {
            var companies = await _companyService.GetAllCompaniesAsync();
            return Ok(companies.Select(c => new { c.Id, c.Name }));
        }
    }
}
