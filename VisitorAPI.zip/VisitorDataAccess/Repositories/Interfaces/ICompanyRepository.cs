﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisitorDataAccess.Entities;

namespace VisitorDataAccess.Repositories.Interfaces
{
    public interface ICompanyRepository
    {
        Task<Company> GetCompanyByIdAsync(long companyId);
        Task<Employee> GetEmployeeByIdAsync(long employeeId);
        Task<IEnumerable<Company>> GetAllCompaniesAsync(); // This could be used for the predefined list of companies
    }
}
