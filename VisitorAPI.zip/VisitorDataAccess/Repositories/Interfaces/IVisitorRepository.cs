﻿using VisitorDataAccess.Entities;
using VisitorDTOs;

namespace VisitorDataAccess.Repositories.Interfaces
{
    public interface IVisitorRepository
    {
        Task AddVisitorAsync(Visitor visitor);          // Add a new visitor
        Task CreateVisitAsync(Visit visit);             // Create a new visit
        Task<Visitor> GetVisitorByEmailAsync(string email); // Get visitor by email
        Task<Visit> GetActiveVisitByVisitorAsync(long visitorId); // Get active visit for a visitor
        Task UpdateVisitAsync(Visit visit);
    }
}
