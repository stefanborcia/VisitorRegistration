﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisitorDataAccess.Entities;
using VisitorDataAccess.Repositories.Interfaces;

namespace VisitorDataAccess.Repositories
{
    public class CompanyRepository:ICompanyRepository
    {
        private readonly VisitorDbContext _dbContext;

        public CompanyRepository(VisitorDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // Get a company by its ID
        public async Task<Company> GetCompanyByIdAsync(long companyId)
        {
            return await _dbContext.Set<Company>().FirstOrDefaultAsync(c => c.Id == companyId);
        }

        // Get an employee by their ID
        public async Task<Employee> GetEmployeeByIdAsync(long employeeId)
        {
            return await _dbContext.Set<Employee>().FirstOrDefaultAsync(e => e.Id == employeeId);
        }

        // Get all companies (for the predefined list of visiting companies)
        public async Task<IEnumerable<Company>> GetAllCompaniesAsync()
        {
            return await _dbContext.Set<Company>().ToListAsync();
        }
    }
}
