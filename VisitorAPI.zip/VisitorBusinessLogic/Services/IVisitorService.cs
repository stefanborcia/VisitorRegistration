﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisitorDTOs;

namespace VisitorBusinessLogic.Services
{
    public interface IVisitorService
    {
        Task RegisterVisitorAsync(SignInVisitorDTO visitorDto);
        //Task<ValidationResult> RegisterVisitorAsync(SignInVisitorDTO visitorDto);
    }
}
