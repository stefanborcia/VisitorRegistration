﻿
using System.Text.RegularExpressions;
using VisitorBusinessLogic.Validation;
using VisitorDataAccess.Entities;
using VisitorDataAccess.Repositories.Interfaces;
using VisitorDTOs;

namespace VisitorBusinessLogic.Services
{
    public class VisitorService : IVisitorService
    {
        private readonly IVisitorRepository _visitorRepository;
        private readonly ICompanyRepository _companyRepository;
        public VisitorService(IVisitorRepository visitorRepository,ICompanyRepository companyRepository )
        {
            _visitorRepository = visitorRepository;
            _companyRepository = companyRepository;
        }

        // Implement the RegisterVisitorAsync method
        public async Task RegisterVisitorAsync(SignInVisitorDTO visitorDto)
        {


            // Create Visitor entity from DTO
            var visitor = new Visitor
            {
                Name = visitorDto.Name,
                Email = visitorDto.Email,
                Company = visitorDto.Company
            };
            // Validate input fields before proceeding
            VisitorValidator.ValidateName(visitorDto.Name);
            VisitorValidator.ValidateEmail(visitorDto.Email);
            VisitorValidator.ValidateVisitingCompanyId(visitorDto.VisitingCompanyId);
            VisitorValidator.ValidateAppointmentWithId(visitorDto.AppointmentWithId);
            // Fetch the company using the company ID from the DTO
            var company = await _companyRepository.GetCompanyByIdAsync(visitorDto.VisitingCompanyId);
            if (company == null)
            {
                throw new Exception("Visiting company not found.");
            }

            // Fetch the employee that the visitor is meeting with
            var employee = await _companyRepository.GetEmployeeByIdAsync(visitorDto.AppointmentWithId);
            if (employee == null || employee.Company.Id != company.Id)
            {
                throw new Exception("Employee not found or does not belong to the selected company.");
            }

            // Add the visitor to the database
            await _visitorRepository.AddVisitorAsync(visitor);

            // Create a new Visit record
            var visit = new Visit
            {
                Visitor = visitor,
                VisitingCompany = company,
                AppointmentWith = employee,
                StartTime = DateTime.Now
            };

            // Create a visit record in the database
            await _visitorRepository.CreateVisitAsync(visit);
        }
    }
}