﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VisitorDTOs;

namespace VisitorBusinessLogic.Validation
{
    public class VisitorValidator
    {
        // Validate Name
        public static VisitorSignInResult ValidateName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                return VisitorSignInResult.Fail("Name is required.");
            }

            return VisitorSignInResult.Success();
        }

        // Validate Email
        public static VisitorSignInResult ValidateEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                return VisitorSignInResult.Fail("Email is required.");
            }

            if (!IsValidEmail(email))
            {
                return VisitorSignInResult.Fail("Invalid email format.");
            }

            return VisitorSignInResult.Success();
        }

        // Validate VisitingCompanyId
        public static VisitorSignInResult ValidateVisitingCompanyId(long visitingCompanyId)
        {
            if (visitingCompanyId <= 0)
            {
                return VisitorSignInResult.Fail("Visiting company is required.");
            }

            return VisitorSignInResult.Success();
        }

        // Validate AppointmentWithId
        public static VisitorSignInResult ValidateAppointmentWithId(long appointmentWithId)
        {
            if (appointmentWithId <= 0)
            {
                return VisitorSignInResult.Fail("Appointment with is required.");
            }

            return VisitorSignInResult.Success();
        }

        // Helper method to validate email format using a regular expression
        private static bool IsValidEmail(string email)
        {
            var emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, emailPattern);
        }
    }
}
